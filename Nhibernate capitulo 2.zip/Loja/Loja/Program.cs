﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Loja.Infra;
using NHibernate.Cfg;
using NHibernate;
using Loja.Entidades;
using Loja.DAO;

namespace Loja
{
    class Program
    {
        static void Main(string[] args)
        {
            ISession session = NHibernateHelper.AbreSession();
            UsuarioDAO usuarioDao = new UsuarioDAO(session);

            Usuario novoUsuario = new Usuario();
            novoUsuario.Nome = "Murilo";

            usuarioDao.adiciona(novoUsuario);

            session.Close();

            Console.Read(); 
        }
    }
}
